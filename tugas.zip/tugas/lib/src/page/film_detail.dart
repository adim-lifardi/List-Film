import 'package:flutter/material.dart';

class DetailFilm extends StatefulWidget {
  final String? title;
  final String? image;
  final String? description;

  const DetailFilm({Key? key, this.title, this.image, this.description}) : super(key: key);

  @override
  State<DetailFilm> createState() => _DetailFilmState();
}

class _DetailFilmState extends State<DetailFilm> {
  String myTitle = '';
  String myImage = '';
  String myDescription = '';

  @override
  void initState() {
    myTitle = widget.title ?? myTitle;
    myImage = widget.image ?? myImage;
    myDescription = widget.description ?? myDescription;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text( myTitle ),  backgroundColor: const Color.fromARGB(209, 95, 208, 242),),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (myImage.isNotEmpty)
              Image.asset(
                myImage,
                fit: BoxFit.cover,
              ),
            const SizedBox(height: 24),
            Text(
              myDescription,
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.justify,
            ),
          ],
        ),
      ),
    );
  }
}
