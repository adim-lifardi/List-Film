import 'package:flutter/material.dart';
import 'package:tugas/src/data/listfilm_model.dart';
import 'package:tugas/src/page/film_detail.dart';

class Film extends StatelessWidget {
  Film({super.key});

  final List<ListModel> ListFilm = [
    ListModel(
      'Jumbo',
      'images/Jumbo.jpg',
      '''Jumbo adalah film animasi dengan genre fantasi petualangan Indonesia tahun 2025 yang disutradarai oleh Ryan Adriandhy dalam debut penyutradaraannya, 
      berdasarkan naskah yang ditulisnya bersama dengan Widya Arifianti.
       Film ini dibintangi oleh Prince Poetiray, Quinn Salman; Bunga Citra Lestari, dan Ariel Noah. 
       Film ini bercerita mengenai Don, seorang anak laki-laki yang berusaha mementaskan sebuah pertunjukan teater dalam sebuah ajang bakat lokal setelah merasa diremehkan oleh teman-temannya.''',
    ),
    ListModel('Agak Laen', 'images/agak laen.jpeg', '''Agak Laen adalah film horor komedi Indonesia tahun 2024 yang disutradarai dan ditulis oleh Muhadkly Acho berdasarkan siniar berjudul sama. 
    Film ini dibintangi oleh personel siniar Agak Laen, yaitu Bene Dion, Oki Rengga, Boris Bokir, dan Indra Jegel. Agak Laen tayang perdana di bioskop Indonesia pada 1 Februari 2024.
    Film ini menjadi film bergenre komedi terlaris Indonesia dengan raihan 9.125.188 penonton, serta pernah menjadi film Indonesia terlaris kedua sepanjang masa sebelum akhirnya Jumbo berhasil menyalip KKN di Desa Penari sebagai film Indonesia terlaris sepanjang masa.'''),
    ListModel('Dilan 1990', 'images/dilan 1990.jpg', '''Dilan 1990 adalah film drama romantis Indonesia tahun 2018 yang disutradarai oleh Fajar Bustomi dan Pidi Baiq. Film ini diangkat dari novel Dilan: Dia adalah Dilanku Tahun 1990 karya Pidi Baiq dan dibintangi oleh Iqbaal Ramadhan dan Vanesha Prescilla. 
    Para pemain pendukungnya antara lain Farhan, Ira Wibowo, Tike Priatnakusumah, dan personel grup idola JKT48, Adhisty Zara. Ridwan Kamil, yang saat rilis film menjabat sebagai Wali Kota Bandung, juga ikut bermain di film ini. Kakak Vanesha, Sissy Priscillia, menjadi narator film sekaligus suara dari Milea dewasa.'''),
    ListModel('Kang Mak from Pee Mak', 'images/kang-mak.jpg', '''Kang Mak from Pee Mak adalah sebuah film horor komedi Indonesia tahun 2024 yang disutradarai oleh Herwin Novianto. Film tersebut menampilkan Vino G. Bastian, Marsha Timothy, Indro Warkop, Tora Sudiro, Indra Jegel, Rigen Rakelna. 
    Film yang dirilis pada 15 Agustus 2024 ini merupakan hasil adaptasi dari film hit bergenre serupa asal Thailand berjudul Pee Mak.'''),
    ListModel('Ipar adalah Maut', 'images/ipar adalah maut.jpg', '''Ipar adalah Maut adalah film drama Indonesia tahun 2024 yang disutradarai oleh Hanung Bramantyo berdasarkan cerita viral berjudul sama karya Elizasifaa. 
    Film ini dibintangi oleh Michelle Ziudith, Deva Mahenra dan Davina Karamoy. Ipar adalah Maut tayang perdana di bioskop pada 13 Juni 2024.'''),
    ListModel('Laskar Pelangi', 'images/laskar-pelangi.jpg', '''Laskar Pelangi adalah sebuah film drama Indonesia tahun 2008 yang disutradarai oleh Riri Riza. Skenario ditulis Salman Aristo bersama Riri dan Mira Lesmana berdasarkan novel berjudul sama karya Andrea Hirata. 
    Film ini diproduksi oleh Miles Films bersama Mizan Productions dan SinemArt.'''),
    ListModel('Milea: Suara dari Dilan', 'images/milea.jpg', '''Milea: Suara dari Dilan adalah film drama romantis Indonesia tahun 2020 yang disutradarai oleh Fajar Bustomi dan Pidi Baiq. Film ini dialih wahana dari novel berjudul sama karya Pidi dan merupakan sekuel dari Dilan 1991 (2019). 
    Kisah film ini diambil dari sudut pandang Dilan dengan menampilkan hal-hal yang tak diceritakan di kedua film sebelumnya.'''),
    ListModel('Sore: Istri dari Masa Depan', 'images/sore.jpg', '''Sore: Istri dari Masa Depan adalah sebuah film sains fiksi romantis Indonesia tahun 2025 yang disutradarai oleh Yandy Laurens dan dibintangi oleh Dion Wiyoko dan Sheila Dara Aisha sebagai pemeran utama. 
    Film ini merupakan remake dari seri web YouTube tahun 2017 dengan judul sama yang sebelumnya juga dibintangi oleh Dion Wiyoko.'''),
    ListModel('Cek Toko Sebelah', 'images/cek toko sebelah.jpg', '''Cek Toko Sebelah (bahasa Inggris: Check the Store Next Door) adalah film drama komedi Indonesia tahun 2016 yang ditulis dan disutradarai oleh Ernest Prakasa. Ide cerita film ini dibuat berdasarkan pada realitas etnis Tionghoa saat anak beranjak dewasa, kuliah yang tinggi, mirisnya ujung-ujungnya bekerja di toko orang tuanya sendiri.
    Film ini ditulis oleh Ernest Prakasa dan Jenny Jusuf dengan pengembangan cerita dari Meira Anastasia.'''),
    ListModel('Home Sweet Loan', 'images/home sweet loan.jpg', '''Home Sweet Loan adalah film drama keluarga Indonesia tahun 2024 yang disutradarai oleh Sabrina Rochelle Kalangie dan dibintangi oleh Yunita Siregar, Derby Romero dan Fita Anggriani. Film ini diadaptasi dari novel berjudul sama karya Almira Bastari dan diproduksi oleh Visinema Pictures. 
    Ceritanya berfokus pada Kaluna (Yunita Siregar), seorang pekerja kantoran dari keluarga sederhana yang bermimpi memiliki rumah sendiri. Sebagai anak bungsu, ia tinggal bersama orang tua, kakak-kakaknya yang sudah berkeluarga, dan keponakan, yang membuat rumahnya terasa ramai dan sering mengganggu kenyamanannya.'''),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Halaman Film',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(209, 95, 208, 242),
      ),
      body: ListView.builder(
        itemCount: ListFilm.length,
        itemBuilder: (context, position) {
          return Container(
            padding: EdgeInsets.all(20),
            child: InkWell(
              child: Row(
                children: [
                  Container(
                    width: 100,
                    padding: EdgeInsets.only(right: 20),
                    child: Image.asset(ListFilm[position].image),
                  ),
                  Text(
                    ListFilm[position].name,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailFilm(
                    title: ListFilm[position].name,
                    image: ListFilm[position].image,
                    description: ListFilm[position].description,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
