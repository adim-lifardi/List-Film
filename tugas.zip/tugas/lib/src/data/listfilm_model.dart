class ListModel {
  String name;
  String image;
  String description;
  ListModel (this.name, this.image, this.description);
}